import React, { HTMLImageElement } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { fetchStreams } from "../../actions";
import history from "../../history";
import { Label, Icon } from "semantic-ui-react";
import "./ShapesGameBoard.css";

class ShapesGameBoard extends React.Component {
  constructor(props) {
    super(props);

    this.props.fetchStreams();
  }
  componentDidMount() {
    console.log("renderes!");
  }
  renderMyUser(stream) {
    if (stream.userId === this.props.currentUserId) {
      return <i id={stream.userId} className="icon user green" />;
    }
    return <i id={stream.userId} className="icon user blue" />;
  }

  renderUserGrid() {
    return this.props.streams.map((stream) => {
      return (
        <a id={stream.id} className="ShapesGameBoard.flex-item">
          
          <Icon name="flag checkered red" inverted />

          <div id={stream.id} className="title ">
            <Label>
              {this.renderMyUser(stream)}
              {stream.id}
            </Label>
          </div>

        </a>
      );
    });
  }

  render() {
    // if (this.props.isSignedIn) {
    if (true) {
      return this.props.streams.map((stream) => {
        return (
          <div className="ShapesGameBoard.flex-container">{this.renderUserGrid(stream)}</div>
        );
      });
    } else {
      return () => {
        history.push("/");
      };
    }
  }
}
const mapStateToProps = (state) => {
  return {
    streams: Object.values(state.streams),
    currentUserId: state.auth.userId,
    isSignedIn: state.auth.isSignedIn,
  };
};

export default connect(mapStateToProps, { fetchStreams })(ShapesGameBoard);
